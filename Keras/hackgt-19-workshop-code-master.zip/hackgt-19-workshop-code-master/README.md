# HackGT 2019: Deep Learning with Keras
This repository contains a collection of code snippets that will be useful to help follow along during the Deep Learning with Keras workshop that I'm running. Slides can be found [here](https://docs.google.com/presentation/d/172hh7cHMhmOTZtjZvpIJw-HXxgKUWkDSY-x_6mgZiiU/edit?usp=sharing).
